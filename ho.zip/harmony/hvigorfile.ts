export { appTasks } from '@ohos/hvigor-ohos-plugin';
