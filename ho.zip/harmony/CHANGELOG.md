
## v0.0.1
	适配兼容OpenHarmony系统，完成相关功能，具体如下：
* Svg: width、height、viewBox、color（不支持动态修改）
* G
* Path: d、fill、stroke、strokeWidth
* Rect: x、y、width、height、rx、ry、fill、stroke、strokeWidth
* Image: x、y、width、height、href
